# Online-Banking-System
<br>
<h2>Author - Kshitij Raj and Ravi Raushan</h2>
<br><br>
<h2>Features</h2>
<ul>
    <li>It can store data</li>
    <li>It can send message to Admin when new account created, account updated or account closed</li>
    <li>It is secure because no one can access anyone account without account number and password</li>
    <li>Only Admin can see anyone data with admin password</li>
</ul>
<br><br>
<h2>For SMS</h2>
<ul>
    <li>First, Sign up on twilio</li>
    <li>After, Sign in, you get api key and auth token</li>
    <li>Then you get phone number</li>
    <li>Now install pip3 install twilio in terminal</li>
    <li>Then Edit api key, auth token and phone number</li>
    <li>And Run the code</li>
</ul>