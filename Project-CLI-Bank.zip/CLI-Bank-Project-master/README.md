<<<<<<< HEAD
# CLI-Bank-Project
Cli bank app


-Welcome to My online banking CLI app.
=======
## CLI ONLINE BANKING APP

![image](https://user-images.githubusercontent.com/61365425/83171597-59ee5280-a0e4-11ea-9c57-1f81b6bddc40.png)

This app is command line take on what a online banking app would look like on the command line. It's also not very strict as a real banking app would be, so enjoy it! :) 

#### Installation--

- To install please fork and clone the app

- Before running run "bundle". This will install the gems needed to run the app. 

  `bundle`
  
 - Head over to the seeds file and uncomment the accounts out. 
 
 - Once done to seed the information run 
 
   `rake db:seed`
   
  - This will seed the bank accounts for you to play with. 
  
 #### Using the App--
 
  - Once in you will be prompted to make an account. Once made if you decide to come back you can just sign in. 
  
  ![image](https://user-images.githubusercontent.com/61365425/83173226-b5214480-a0e6-11ea-8ca8-2a332a2805ff.png)
  
  - If you forget your password you can reset it by typing you username and phone number
  
  ![Screen Shot 2020-05-28 at 1 32 21 PM](https://user-images.githubusercontent.com/61365425/83177427-0cc2ae80-a0ed-11ea-9922-ceaffc32f0f0.png)

  
  - You will have the option of opening any of the 4 accounts ("Checking","Savings" etc ..) You can open more accounts once in the menu.
  
  ![Screen Shot 2020-05-28 at 2 12 09 PM](https://user-images.githubusercontent.com/61365425/83177546-41366a80-a0ed-11ea-9c97-ef7c5b172366.png)
  
  - From here on out you can play around with the features. To transfer money you need to enter the person's username exactly as written. 
  
  - If you open a CD or credit card these accounts are non withdrawable. You cant take money from them once opened
  
  - The app also features a Elite member system if you meet the criteria you can head to "More options" and apply to be a premium member. 
  
  ![Screen Shot 2020-05-28 at 2 16 55 PM](https://user-images.githubusercontent.com/61365425/83178018-efdaab00-a0ed-11ea-96b3-bb75809798d1.png)
  
  - There is 3 tiers depending on your balances you will qualify for them and get a cool badge "Gold" -> "Silver" -> "Diamond"
  
  - Hope you enjoy it! 
  
  
  
  
  
  
 
 
>>>>>>> c2103b3b0b2db75b9d89658d43d76d42ca086f35
