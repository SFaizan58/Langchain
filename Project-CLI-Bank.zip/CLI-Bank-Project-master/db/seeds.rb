# Bank.create(accounts:"Premier Checking Account", monthly_fee:5, interest_rate:"0.01 % APY", withdrawable:t)
# Bank.create(accounts:"Premier Savings Account", interest_rate:"0.90 % APY", withdrawable:t)
# Bank.create(accounts:"Premier Credit Card", interest_rate:"17.85 % APR", withdrawable:f)
# Bank.create(accounts:"Premier Certificate of Deposit", interest_rate:"2.50 % APY", withdrawable:f)